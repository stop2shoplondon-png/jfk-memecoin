# JFK Meme Coin – GitHub Pages

This repo hosts a static HTML page for JFK Meme Coin.

## Quick Start
1. Create a new GitHub repository (e.g. `jfk-memecoin`).
2. Upload **index.html** and **jfk_memecoin.html** from this folder to the repo root.
3. Go to **Settings → Pages**.
4. Under **Source**, choose **Deploy from a branch**.
5. Select **main** branch and **/ (root)** folder, then **Save**.
6. Your site will be live at:
   - `https://<your-username>.github.io/jfk-memecoin/` (serves `index.html`)
   - `https://<your-username>.github.io/jfk-memecoin/jfk_memecoin.html`

If MetaMask popups do not open inside Canva (iframe), open the site directly in your browser.
